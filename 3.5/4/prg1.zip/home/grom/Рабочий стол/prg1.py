matrix = {}

print("Введите количество строк ", end="\n")
n = int(input())
print("\nВведите количество столбцов ", end="\n")
m = int(input())

for i in range(n):
    for j in range(m):
        print("\nВведите (" + str(i) + "," +
              str(j) + ") элемент матрицы: ", end="\t")
        matrix[i, j] = int(input())

print("\n")
print("\nВведите число i:", end="\n")
i = int(input())
print("\nВведите число j:", end="\n")
j = int(input())
print(matrix[i, j])
